#include <math.h>
#include <stdio.h>
#include <conio.h>
int gtdt(int n,int a[],int b)
{
    int i,s;
    for (s=0,i=0;i<n;i++)
    {
        s=s+a[i]*pow(b,i);
    }
    return s;
}
int main(){
    int i,cn,x,P,Q,T,n,m,hsP,hsQ,hsT;
    printf("Nhap x de thuc hien cac chuc nang khac : "); scanf("%d",&x);
    menu:
    printf("\nMenu:\n1.Nhap he so cua hai da thuc P Q\n2.Tinh he so cua da thuc T\n3.In he so cua 3 da thuc P,Q,T\n4.In gia tri cua 3 da thuc P,Q,T\n5.Ket thuc\nChon : ");
    scanf("%d",&cn);
        switch(cn)
    {
    case(1):
        {
            hsT=0; hsQ=0; hsP=0;
            printf("\nNhap so phan tu cua P : "); scanf("%d",&n);
            int a[n];
           for(i=n-1;i>=0;i--)
           {
             printf("a[%d] = ",i); scanf("%d",&a[i]);
             hsT= hsT + a[i];
             hsP= hsP + a[i];
           }
            printf("Nhap so phan tu cua Q : "); scanf("%d",&m);
            int b[m];
            for(i=m-1;i>=0;i--)
            {
             printf("b[%d] = ",i); scanf("%d",&b[i]);
             hsT= hsT + b[i];
             hsQ= hsQ + b[i];
           }
           printf("Hoan thanh ! Moi ban tiep tuc chon cac chuc nang. \n\n\n");
           P=gtdt(n,a,x); Q=gtdt(m,b,x); T=P+Q;
           goto menu;
        }
    case(2):
        {
            printf("\nHe so cua da thuc T la : %d\n",hsT);
            printf("Hoan thanh ! Moi ban tiep tuc chon cac chuc nang. \n\n\n");
            goto menu;
        }
    case(3):
        {
            printf("\nHe so P = %d\t Q = %d\t T = %d ",hsQ,hsP,hsT);
            printf("\nHoan thanh ! Moi ban tiep tuc chon cac chuc nang. \n\n\n");
            goto menu;
        }
    case(4):
        {
            printf("\nGia tri P = %d\t Q = %d\t T = %d ",P,Q,T);
            printf("\nHoan thanh ! Moi ban tiep tuc chon cac chuc nang. \n\n\n");
            goto menu;
        }
    case(5):
        {
            printf("\n\nKET THUC CHUONG TRINH"); break;
        }
    default : goto menu;
    }
}
