#include <stdio.h>
int main(){
int n,m,i,j,lon,nho;
printf("Nhap so hang : "); scanf("%d",&n);
printf("Nhap so cot : "); scanf("%d",&m);
int a[n][m];
for(i=0;i<n;i++)
for(j=0;j<m;j++){
    printf("Phan tu [%d,%d] = ",i,j); scanf("%d",&
                                            a[i][j]);
}
lon=a[0][0];
nho=a[0][0];
printf("In ma tran : \n");
for(i=0;i<n;i++){
for(j=0;j<m;j++){
    printf("%d\t",a[i][j]);
    if(lon<a[i][j]) lon=a[i][j];
    if(nho>a[i][j]) nho=a[i][j];
}
printf("\n");
}
printf("\nPhan tu lon nhat = %d \nPhan tu nho nhat = %d\n",lon,nho);
}
