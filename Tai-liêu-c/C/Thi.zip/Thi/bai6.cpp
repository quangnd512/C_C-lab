#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
int a,b,x,temp;
printf("Nhap vao so a = "); scanf("%d",&a);
printf("Nhap vao so b = "); scanf("%d",&b);
x=a*b;
while (temp!=0){
        temp= a%b;
        a=b;
        b=temp;
 }
printf("BCNN = %d",((x)/a));
}
