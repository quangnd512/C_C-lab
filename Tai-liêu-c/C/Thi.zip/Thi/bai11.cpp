#include <stdio.h>
#include <stdlib.h>
#define NAME_LEN 30
#include <string.h>
int menu () {
 printf("\n\n\n------------------[ Menu ]-----------------\n");
 printf(" - 1. Tao Danh Sach Sinh Vien.             -\n");
 printf(" - 2. Hien Thi Danh Sach Sinh Vien.        -\n");
 printf(" ___________________________________________\n");
 printf(" - 3. Chen Them Sinh Vien                  -\n");
 printf(" - 4. Xoa Mot Sinh Vien.                   -\n");
 printf(" - 5. Sua Mot Sinh Vien                    -\n");
 printf(" ___________________________________________\n");
 printf(" - 6. Ket Thuc.                            -\n");
printf(" -----------------===========----------------\n");
printf(" ____________________________________________\n");
 printf(" - Chon  : ");
    int chon;
    scanf("%d", &chon);
    return chon;
}
typedef struct SinhVien{
    char hoten[NAME_LEN];
    int tuoi;
    float diemtb;
    struct SinhVien *next;
}SinhVien;

SinhVien *first = NULL;
SinhVien *last = NULL;
char ten_file[] = "dssv.bin";
void Tao_Danh_Sach () {
    SinhVien *sv;
    char Tiep_tuc;
    int stt = 0;
    do {

        sv = (SinhVien*)malloc(sizeof(SinhVien));
        printf("------THONG TIN SINH VIEN THU %d ------\n",++stt);
        printf("Ho Ten: ");
        fflush(stdin);
        gets(sv->hoten);
        printf("Tuoi: ");
        scanf("%d",&sv->tuoi);
        printf("Diem Trung Binh: ");
        scanf("%f",&sv->diemtb);
        sv->next = NULL;

        if (first == NULL) {
            first = sv;
            last = sv;
        }
        else {
            last->next = sv;
            last = sv;
        }


        printf("Ban co nhap nua khong ? (y/n) ");
        fflush(stdin);
        scanf("%c",&Tiep_tuc);
    }while (Tiep_tuc!='n' && Tiep_tuc!='N');
}
void Hien_Thi_Danh_Sach () {
    int stt = 0 ;
printf("\n\n-------DANH SACH SINH VIEN-------\n");
printf("STT\t\tHo Ten\t\t\tTuoi\t\tDiem TB\n");
SinhVien *sv = first;
while (sv != NULL)
{
printf("%d\t\t%s\t\t%d\t\t%0.2f\n",++stt,sv -> hoten,sv -> tuoi,sv -> diemtb);
sv= sv->next;
}
}

SinhVien *Tim_Sinh_Vien (char hoten[]) {
    SinhVien *sv = first;
    while (sv!=NULL && strcmp(hoten, sv->hoten)!=0) {
        sv = sv->next;
    }
    return sv;
}
SinhVien *Tim_Sinh_Vien_Truoc(SinhVien *sv) {
    if (sv == first) {
        return NULL;
    }
    SinhVien *preview = first;
    while (preview->next!=sv) {
        preview = preview->next;
    }
    return preview;
}
void Chen_Them_Sinh_Vien () {
    char hoten[NAME_LEN];
    printf("Ban muon chen truoc sinh vien nao ? Nhap ten : ");
    fflush(stdin);
    gets(hoten);
    SinhVien *after = Tim_Sinh_Vien (hoten);
    if (after == NULL) {
        printf("khong tim thay sinh vien %s\n",hoten);
    }
    SinhVien *new_sv;
    new_sv = (SinhVien*)malloc(sizeof(SinhVien));
    printf("============THONG TIN SINH VIEN MOI==========\n");
    printf("Ho Ten: ");
    fflush(stdin);
    gets(new_sv->hoten);
    printf("Tuoi: ");
    scanf("%d",&new_sv->tuoi);
    printf("Diem Trung Binh: ");
    scanf("%f",&new_sv->diemtb);
    new_sv->next = NULL;

    SinhVien *preview = Tim_Sinh_Vien_Truoc(after);
    if (preview == NULL) {
        new_sv->next = after;
        first = new_sv;
    }
    else {
        new_sv->next = after;
        preview->next = new_sv;
    }
}
void Xoa_Sinh_Vien () {
    SinhVien *sv;
    printf("\n\n-------XOA SINH VIEN-------\n");
    printf("Ho Ten - Sinh Vien Can Xoa : ");
    char hoten[NAME_LEN];
    fflush(stdin);
    gets(hoten);
    //tìm sinh viên
    sv = Tim_Sinh_Vien(hoten);
    if (sv == NULL) {
        printf("------> Khong tim thay sinh vien can xoa\n");
        return;
    } else printf("-----> Da xoa xong \n\n");
    //xóa sinh viên
    SinhVien *preview = Tim_Sinh_Vien_Truoc(sv);
    if (preview == NULL) {
        first = first->next;
    }
    else {
        preview->next = sv->next;
    }
    free(sv);
}
void Sua_Sinh_Vien () {
    char hoten[NAME_LEN];
    printf("nhap vao ho ten sinh vien: ");
    fflush(stdin);
    gets(hoten);
    SinhVien *sv = first , *sv_tim;
    sv_tim = Tim_Sinh_Vien(hoten);
    if (sv_tim == NULL) {
        printf("--> Khong tim thay sinh vien can sua\n");
        return;
    }
    while (sv!=NULL) { //duyệt
        if (strcmp(sv->hoten, hoten) == 0) {
          printf("\n\n-------THONG TIN SINH VIEN CAN SUA-------\n");
            printf("Ho Ten\t\t\tTuoi\t\tDiem TB\n");
            printf("%s\t\t%d\t\t%0.2f\n",sv -> hoten,sv -> tuoi,sv -> diemtb);
            printf("\n\n-------CAP NHAP THONG TIN-------\n");
            printf("Ho Ten : "); fflush(stdin); gets(sv -> hoten);
            printf("Tuoi : "); scanf("%d",&sv -> tuoi);
            printf("Diem Trung Binh : "); scanf("%f",&sv -> diemtb);
            printf("-----> Da sua xong \n\n");
        }
        sv = sv->next;
    }
}
int main()
{
    int da_chon;
    do {
        da_chon = menu();
        switch (da_chon) {
            case 1: {
                Tao_Danh_Sach();
            }break;
            case 2: {
                Hien_Thi_Danh_Sach();
            }break;
            case 3: {
                Chen_Them_Sinh_Vien();
            }break;
            case 4: {
                Xoa_Sinh_Vien();
            }break;
            case 5: {
                Sua_Sinh_Vien();
            }break;
            case 6:{
            printf("========= KET THUC CHUONG TRINH =========");
            }
        }
    }while (da_chon!=6);
    return 0;
}
