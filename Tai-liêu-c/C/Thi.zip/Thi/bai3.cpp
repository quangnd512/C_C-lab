#include <stdio.h>
#include <math.h>
int main()
{
    int n,i,j,temp;
    printf("Nhap vao so phan tu cua day so : "); scanf("%d",&n); //nhap vao gia tri n
    int a[n]; // Khai bao mang a co n phan tu
    for(i=1;i<=n;i++){
        printf("a[%d] = ",i); scanf("%d",&a[i]); // dung vong for nhap vao gia tri cac phan tu tu 1 -> n
    }
    printf("Day so ban dau la : \n"); // In day so ban dau
     for(i=1;i<=n;i++){
        printf("%d\t",a[i]);
    }
    //--------> Thoat toan sap xep dung bien trung gian <-------//
    for(i=1;i<=n-1;i++)
      for(j=i+1;j<=n;j++)
       if(a[i]>a[j]){
       temp=a[i];
       a[i]=a[j];
       a[j]=temp;
    }
    printf("\nDay so duoc sap xem tu be den lon la : \n"); // In day so sau khi duoc sap xep
     for(i=1;i<=n;i++){
        printf("%d\t",a[i]);
    }
}
