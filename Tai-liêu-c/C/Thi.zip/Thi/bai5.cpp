#include <stdio.h>
#include <math.h>
#include <stdlib.h>
int main(){
int n,kq,i;
printf("Nhap vao n! muon tinh : "); scanf("%d",&n);
if(n<0){
    for(kq=1,i=1;i<=abs(n);i++) kq = kq*i;
printf("Ta co : %d! = %d",n,-kq);
}
else if(n==0) printf("Ta co : 0! = 1");

else{
for(kq=1,i=1;i<=n;i++) kq = kq*i;
printf("Ta co : %d! = %d",n,kq);
}
}
