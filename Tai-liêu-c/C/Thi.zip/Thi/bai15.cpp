#include <stdio.h>
#include <math.h>
#include <stdlib.h>
int main()
{
    int cn;
    FILE *f;
    menu:
    printf("\n\nMenu\n1. Doc tep MA_TRAN.c\n2. Ghi ma tran C bo sung vao cuoi tep tren\n3. Ket thuc\n- Chon : ");
    scanf("%d",&cn);
    switch(cn)
    {
    int n,m,i,j;
    char tb[100];
    int a[100][100],b[100][100],c[100][100];
    case(1):
    {
    f = fopen("MA_TRAN.c" , "r");
    fscanf(f,"%d %d",&n,&m); // Nhap m , n

    ///------Lay du lieu ma tran A -------///
    fgets(tb, 100, f);
    fgets(tb, 100, f);
    for(i=1; i<=n;i++)
    {
    for(j=1; j<=m;j++)
    fscanf(f,"%d", &a[i][j]);
    fgets(tb, 100, f);
    }
    ///-----Lay du lieu ma tran B-----///
    fgets(tb, 100, f);
    for(i=1; i<=n;i++)
    {
    for(j=1; j<=m;j++)
    fscanf(f,"%d", &b[i][j]);
    fgets(tb, 100, f);
    }
fclose(f);
printf("\nDa doc tep MA_TRAN.c !! Vui long chon cac chuc nang khac . \n");
printf("\n=======Ma Tran A(%d x %d)=======\n",n,m);
for(i=1; i<=n;i++){
        printf("\t");
    {
    for(j=1; j<=m;j++) printf("%d\t",a[i][j]);
}
printf("\n");
}
printf("\n=======Ma Tran B(%d x %d)=======\n",n,m);
for(i=1; i<=n;i++){
    printf("\t");
    {
    for(j=1; j<=m;j++) printf("%d\t",b[i][j]);
}
printf("\n");
}
goto menu;
    }
case(2):
    {
///-------> Tinh Tong hai ma tran <----///
for(i=1; i<=n;i++)
    {
    for(j=1; j<=m;j++) c[i][j]=a[i][j]+b[i][j];
}
f = fopen("MA_TRAN.C", "at");
fprintf(f,"Ma Tran C\n");
for(i=1; i<=n;i++){
    {
    for(j=1; j<=m;j++) fprintf(f,"%d ",c[i][j]);
}
fprintf(f,"\n");
}
printf("\nTinh tong hai ma tran C....\nGhi C vao tep MA_TRAN.c....\nHoan Thanh !! Vui long chon cac chuc nang khac . \n");
goto menu;
}
case(3):
    {
        printf("======KET THUC CHUONG TRINH======="); break;
    }
default:goto menu;
    }
}
