#include <stdio.h>
#include <math.h>
#include <conio.h>

int main()
{
    int cn;
    menu:
    printf("\n\nMenu : \n1. Nhap 2 ma tran\n2. Tinh tinh 2 ma tran\n3. Hien thi 3 ma tran\n4.Ket thuc\n-Chon : ");
    scanf("%d",&cn);
    switch(cn)
    {
    int i,j,n,p,m,k;
    int a[100][100],b[100][100],c[100][100];
case(1):
    {
    printf("Tinh tic hai ma tran co dang A(nxp) x B(pxm) = C(nxm)\n");
    printf("Nhap n : "); scanf("%d",&n);
    printf("Nhap p :" ); scanf("%d",&p);
    printf("Nhap m : "); scanf("%d",&m);
    printf("Nhap vao cac phan tu cua ma tran thu nhat A(%d x %d):\n",n,p);
    for(i=0;i<n;i++)
        for(j=0;j<p;j++)
    {
        printf("Phan tu - [%d,%d]: ",i,j);
        scanf("%d",&a[i][j]);
    }
    printf("Nhap vao cac phan tu cua ma tran thu hai B(%d x %d):\n",p,m);
    for(i=0;i<p;i++)
        for(j=0;j<m;j++)
    {

        printf("Phan tu - [%d,%d]: ",i,j);
        scanf("%d",&b[i][j]);
    }
    goto menu;
    }
case(2):
    {
for(i=0;i<n;i++)
{
    for(k=0;k<m;k++)
{
    c[i][k]=0;
    for(j=0;j<p;j++)
    {
        c[i][k]=c[i][k]+a[i][j]*b[j][k];
    }
}
}
printf("\nTinh tich cua hai ma tran ! \nHoan Thanh !! Vui long chon cac chuc nang khac !\n");
goto menu;
    }

case(3):
    {
printf("In ma tran thu nhat:\n");
    for(i=0;i<n;i++)
    {
        for(j=0;j<p;j++)
        {
            printf("%d\t",a[i][j]);
        }
        printf("\n");
    }
    printf("In ma tran thu hai:\n");
    for(i=0;i<p;i++)
    {
        for(j=0;j<m;j++)
        {
        printf("%d\t",b[i][j]);
        }
        printf("\n");
    }
printf("Ma tran tich cua hai ma tran tren la :\n");
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
        printf("%d\t",c[i][j]);
        }
        printf("\n");
    }
goto menu;
}
case(4):{printf("KET THUC CHUONG TRINH"); break;}
default: goto menu;
    }
}
