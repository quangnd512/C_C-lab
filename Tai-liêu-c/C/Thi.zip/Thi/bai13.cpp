#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct StackItem
{
    char value;
    struct StackItem *prev;
}StackItem;

StackItem *top;

int menu()
{
    int chon;
    printf("1. Chuyen sang he co so 2\n");
    printf("2. Chuyen sang he co so 8\n");
    printf("3. Chuyen sang he co so 16\n");
    printf("4. Ket thuc\n");
    printf("=================================\n");
    printf("Ban chon: ");
    scanf("%d", &chon);
    return chon;
}

void push(StackItem item)
{
    StackItem *p;
    p = (StackItem*)malloc(sizeof(StackItem));
    p->value = item.value;
    p->prev = top;
    top = p;
}

StackItem pop()
{
    StackItem res;
    res.value = top->value;

    StackItem *temp = top;
    top = top->prev;
    free(temp);

    return res;
}
void hien_ket_qua()
{
    StackItem *item = top;
    while(item != NULL)
    {
        printf("%c", item->value);
        item = item->prev;
    }
    printf("\n");
}
void chuyen_co_so(int base)
{
    StackItem item;
    int n;
    char r;
    top = NULL;
    printf("Nhap so can chuyen: n = ");
    scanf("%d", &n);
    do
    {
        r = n%base;
        if(r<10)
            r += '0';
        else
            r = r-10+'a';
        item.value = r;
        push(item);
        n = n/base;
    }while(n!=0);
    printf("Bieu dien can co la:\n");
    hien_ket_qua();
}


int main()
{
    int da_chon;
    do
    {
        da_chon = menu();
        switch(da_chon)
        {
        case 1:
            chuyen_co_so(2);
            break;
        case 2:
            chuyen_co_so(8);
            break;
        case 3:
            chuyen_co_so(16);
            break;
        }
    }while (da_chon!=4);
    return 0;
}
