#include<stdio.h>
#include<math.h>
int a[50][50],n,j,i,gt,d,hang,cot,s;

main(){
    int cn,n;
     menu:
     printf("\nMenu\n1.Nhap n \n2.Tinh ma tran xoay \n3.Hien thi ma tran xoay \n4.Ket thuc\n-Chon: ");
     scanf("%d",&cn);

switch(cn)
{
case(1):
    {
    printf("\n nhap n>0: ");
	scanf("%d",&n);
    printf("\nHoan thanh ! Moi ban tiep tuc chon cac chuc nang. \n\n\n");
    goto menu;
    }
case(2):
    {
        d=0; gt=1; hang=n-1; cot=n-1; s=0;
	    while(d<=n/2){
		for(i=d;i<=cot;i++) a[d][i]=gt++;
		for(i=d+1;i<=hang;i++) a[i][cot]=gt++;
		for(i=cot-1;i>=d;i--) a[hang][i]=gt++;
		for(i=hang-1;i>d;i--) a[i][d]=gt++;
		d++; hang--; cot--;
	    }
        printf("\nTao ma tran ..... \nHoan thanh ! Moi ban tiep tuc chon cac chuc nang. \n\n\n");
        goto menu;
    }
case(3):
    {
    for(i=0;i<n;i++){
		for(j=0;j<n;j++)
			printf("%5d",a[i][j]);
		printf("\n\n\n");
	}
    printf("\nHoan thanh ! Moi ban tiep tuc chon cac chuc nang. \n\n\n");
    goto menu;
    }
case(4):
    {
        printf("\nKET THUC CHUONG TRINH. \n\n\n");
        break;
    }
default: goto menu;
}
}

