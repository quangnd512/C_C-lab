2 3
Ma Tran A
3 4 4
4 5 7
Ma Tran B
5 6 8
5 1 2
