#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,lon,nho,csmax,csmin,i;
    printf("Nhap vao so phan tu :"); scanf("%d",&n);
    int a[n];
    for(i=1;i<=n;i++)
    {
        printf("a[%d] = ",i); scanf("%d",&a[i]);
    }
    for(i=2,csmax=1,csmin=1,lon=a[1],nho=a[1];i<=n;i++)
    {
        if (a[i]>lon){csmax=i; lon=a[i];}
        if (a[i]<nho){csmin=i; nho=a[i];}
    }
    printf("So lon nhat %d o vi tri %d\n",lon,csmax);
    printf("So nho nhat %d o vi tri %d",nho,csmin);

}
