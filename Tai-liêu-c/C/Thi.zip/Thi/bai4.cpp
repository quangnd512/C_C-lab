//He phuong trinh
//ax+by=c
//dx+ey=f
#include<stdio.h>
#include<conio.h>
#include<math.h>
int main(){
int a,b,c,d,e,f;
int kt=0,dy=0,dx=0;
printf("\nGiai he phuong trinh bac nhat 2 an \n//ax + by =c\n//dx + cy = f\n");
printf("a = "); scanf("%d",&a);
printf("b = "); scanf("%d",&b);
printf("c = "); scanf("%d",&c);
printf("d = "); scanf("%d",&d);
printf("e = "); scanf("%d",&e);
printf("f = "); scanf("%d",&f);
kt=a*e-d*b;
dx=c*e-f*b;
dy=a*f-d*c;
if(kt!=0){
printf("\nHe phuong trinh co nghiem duy nhat");
printf("\nGia tri x = %d",dx/d);
printf("\nGia tri y = %d",dy/d);
}
else if((kt==0&&dx!=0) || (kt==0&&dy!=0) || (a==0&&b==0&&d==0&&e==0&&c!=0&&f!=0) || (a==0&&b==0&&d==0&&e==0&&c==0&&f!=0) || (a==0&&b==0&&d==0&&e==0&&c!=0&&f==0)){
printf("\nHe phuong trinh vo nghiem");
}
else if(kt==0&&dx==0&&dy==0 || (a==0&&b==0&&d==0&&e==0&&c==0&&f==0)){
printf("\nHe phuong trinh co vo so nghiem");
}
getch();
}
