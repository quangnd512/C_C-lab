#include <stdio.h>
#include <math.h>

int main()
{
int c[1000],i, j, n,m,z,dem,temp;
  printf("Nhap so phan tu day thu nhat :"); scanf("%d",&n);
  int a[n];
  dem=1;
  printf("Nhap so phan day thu nhat theo chieu tang dan :\n");
  for (i=1;i<=n;i++,dem++)
  {
      printf("a[%d] = ",i); scanf("%d",&a[i]);
      c[dem]=a[i];
  }
  printf("Nhap so phan tu day hai nhat :"); scanf("%d",&m);
  int b[m];
  z=m+n;
  printf("Nhap so phan day thu hai theo chieu tang dan :\n");
  for (i=1;i<=m;i++,dem++)
  {
      printf("b[%d] = ",i); scanf("%d",&b[i]);
      c[dem]=b[i];
  }
  printf("\nDay so mot la :");
  for (i = 1; i <= n; i++) printf("%d\t",a[i]);
  printf("\nDay so hai la :");
  for (i = 1; i <= m; i++) printf("%d\t",b[i]);


  for (i = 1; i < dem; i++)
    for (j = i + 1; j <= dem; j++)
    {
     if (c[i] > c[j])
       {
        temp = c[i];
        c[i] = c[j];
        c[j] = temp;
        }
    }
    printf("\nDay so ba la :");
 for (j=1; j<dem; j++)    printf("%d \t",c[j]);
}
