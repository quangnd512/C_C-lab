#include<conio.h>
#include<stdio.h>

int main()
{
    float a,b,c;
    printf("Nhap vao 3 so a , b , c : \n");
    printf("a= ");
    scanf("%f",&a);
    printf("b= ");
    scanf("%f",&b);
    printf("c= ");
    scanf("%f",&c);
    if ((a+b>=c)&&(b+c>=a)&&(c+a>=b)&&(a!= 0 && b!=0 && c!=0))
    {
        printf("a , b , c la ba canh cua Tam Giac ");
        if (((a==b)&&((a!=c)||(b!=c))) || ((a==c)&&((a!=b)||(c!=b))) || ((c==b)&&((c!=a)||(b!=a))))
            printf("Can.");
        else if((a==b)&&(b==c))
            printf("Deu.");
        else if((a*a==b*b+c*c) || (b*b==a*a+c*c) || (c*c==b*b+a*a))
            printf("Vuong.");
        else if((a*a==b*b+c*c) && ((a==b)&&((a!=c)||(b!=c))) || (b*b==a*a+c*c) && ((a==c)&&((a!=b)||(c!=b))) || (c*c==b*b+a*a) && ((c==b)&&((c!=a)||(b!=a))))
            printf("Vuong Can.");
        else
            printf("Tam giac Thuong!");
    }
    else
        printf("a ,b , c khong thoa man la 3 canh cua tam giac!\n");
    getch();
    return 0;
}
