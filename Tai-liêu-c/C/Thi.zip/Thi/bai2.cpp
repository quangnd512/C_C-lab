#include <stdio.h>
#include <conio.h>
int main()
{
    int nam;
    float GDP, GDPmoc, tttt;   // tttt la toc do tang truong binh quan
    printf ("Tong thu nhap GDP nuoc ta\n");// hien thi ra man hinh
    printf ("nhap nam khoi dau : ");// hien thi ra man hinh
    scanf ("%d",&nam); // nhap gia tri nam
    printf ("nhap GDP nam khoi dau : ");// hien thi ra man hinh
    scanf ("%f",&GDP); // nhap gia tri gdp
    printf ("nhap toc do tang truong trung binh : ");// hien thi ra man hinh
    scanf ("%f",&tttt); // nhap gia tri tttt
    printf ("\nNam\tGDP ( don vi: ti USD )");// hien thi ra man hinh
    printf ("\n%d\t%.2f",nam,GDP);// hien thi ra man hinh
    GDPmoc = GDP;
    while ( GDP < 2*GDPmoc ) //dieu kien
    {
        nam++;
        GDP=GDP+tttt;
        printf ("\n%d\t%.2f",nam,GDP);
    }
    return 0;
}
