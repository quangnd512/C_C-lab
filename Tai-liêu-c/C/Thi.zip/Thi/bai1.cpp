#include <stdio.h>
#include <math.h>


int main(){
float a,b,c,d; //khoi tao bien
printf("Nhap lan luot cac he so a b c cua phuong trinh ax^2 + bx + c = 0 la :\n");
//-----> Nhap du lieu vao tu ban phim <------//
printf("\ta = "); scanf("%f",&a);
printf("\tb = "); scanf("%f",&b);
printf("\tc = "); scanf("%f",&c);
//----->Thoat toan tinh nghiem<------//
if(a==0) //Neu a<0
{
    if(b==0) //Xet tiep den b
    {
        if(c==0)//Xet tiep den c
            {
            printf("Phuong trinh VO SO NGHIEM"); //neu a,b,c dong thoi bang 0 thi phuong trinh vo so nghiem
            }
        else printf("Phuong trinh VO NGHIEM"); //neu a,b = 0 ma C khac 0 thi phuong trinh vo nghiem
    }
    else printf("Phuong trinh co nghiem x = %0.2f ",((-c)/b)); // a=0 ,b & c #0 thi phuong trinh tro thanh bx + c = 0 => x=-c/a
}
else if(a!=0){ // a b c deu khac 0 nen phuong tinh tro ve ban dau
d=pow(b,2)-4*a*c; // tinh delta
//-----------> Xet delta <---------
if(d<0) printf("Phuong trinh VO NGHIEM"); // Delta < 0 nen phuong trinh vo nghiem
else if(d==0) printf("Phuong trinh co nghiem duy nhat x = %0.2f", (-b/(2*a))); // delta = 0 nen phuong trinh co nghiem kep
else if (d>0) printf("Phuong trinh co hai nghiem : \n x1 = %0.2f \n x2 = %0.2f",((-b - sqrt(d))/2*a),((-b + sqrt(d))/2*a));
}
}
